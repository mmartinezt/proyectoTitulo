<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
    <div class="body-content">
breadcrumbs->home

<table width = "100%" weight="500px" border="1" style="border-collapse:collapse;">
	<tr>
		<td width ="100%" >	
			slider ofertas y promociones
		</td>
	</tr>
	<tr style="border:none;">
		<td width ="100%" >	
			slider 1... slider 2... slider 3...
		</td>
	</tr>
	<tr>
		<td width="10%" style="text-align:center; margin:100px; padding:100px;">cuerpo de slider</td>
	</tr>
	<tr style="border:none;">
		<td width ="100%" style="text-align: right">	
			control de slider
		</td>
	</tr>
</table>
<br/>
<br/>
<br/>
<table width="100%" border="1">
<tr>
	<td width="25%"> Categorías productos</td>
	<td width="75%"> Slider publicidad de la empresa, folletos, medios de pagos, descuentos del mes etc...</td>
</tr>	
</table>


<div style="padding: 10px; float: left; width: 25%; text-align: justify;">
	<table width="100%" border="1">
		<tr>
			<td width="25%"> categoría 1</td>
		</tr>	
	</table>
	<table width="90%" border="1" align="right">
		<tr>
			<td width="25%"> sub-categoría 1</td>
		</tr>	
		<tr>
			<td width="25%"> sub-categoría 2</td>
		</tr>	
		<tr>
			<td width="25%"> sub-categoría 3</td>
		</tr>	
		
	</table>
	
	<table width="100%" border="1">
		<tr>
			<td width="25%"> categoría 2</td>
		</tr>	
	</table>
	<table width="90%" border="1" align="right">
		<tr>
			<td width="25%"> sub-categoría 1</td>
		</tr>	
		<tr>
			<td width="25%"> sub-categoría 2</td>
		</tr>	
		<tr>
			<td width="25%"> sub-categoría 3</td>
		</tr>	
		
	</table>
	
	<table width="100%" border="1">
		<tr>
			<td width="25%"> categoría 3</td>
		</tr>	
	</table>
	<table width="90%" border="1" align="right">
		<tr>
			<td width="25%"> sub-categoría 1</td>
		</tr>	
		<tr>
			<td width="25%"> sub-categoría 2</td>
		</tr>	
		<tr>
			<td width="25%"> sub-categoría 3</td>
		</tr>	
		
	</table>

</div>

<div style="padding: 10px; float: right; width: 75%; text-align: right;">
		<center>
		
			<img src="images/banner1.jpg" />
		
			<br/>
		</center>
		<span>(Imagen referencial)</span>
		
	<table width="100%" border="1" align="center">
		<tr>
			<td width="25%" align="center" style="margin:30px; padding:30px;"> banner1</td>
			<td width="25%" align="center"> banner2</td>
			<td width="25%" align="center"> banner3</td>
		</tr>	
		
	</table>
		
	
</div>
</br></br></br></br></br></br></br></br>
</br></br></br></br></br></br></br></br>
</br></br></br></br></br></br></br></br>
</br></br></br>

<center>
Logos de empresas asociados
</br>
ctrl izquierda
<img src="images/logos.png"/>
ctrl derecha
</br>
(imagen referencial)
</center>



        




   

    </div>
</div>

