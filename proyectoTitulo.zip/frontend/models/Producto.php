<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "producto".
 *
 * @property integer $id_prodcto
 * @property integer $id_categoria_producto
 * @property integer $id_subcategoria_producto
 * @property string $nombre_producto
 * @property string $id_marca_producto
 * @property string $descripcion
 * @property integer $stock
 * @property string $path_imagen
 * @property integer $precio_compra
 * @property integer $precio_venta
 */
class Producto extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'producto';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_categoria_producto', 'id_subcategoria_producto', 'nombre_producto', 'id_marca_producto', 'descripcion', 'stock', 'path_imagen', 'precio_compra', 'precio_venta'], 'required'],
            [['id_categoria_producto', 'id_subcategoria_producto', 'stock', 'precio_compra', 'precio_venta'], 'integer'],
            [['nombre_producto', 'descripcion'], 'string', 'max' => 500],
            [['id_marca_producto'], 'string', 'max' => 100],
            [['path_imagen'], 'string', 'max' => 200],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_prodcto' => 'Id Prodcto',
            'id_categoria_producto' => 'Id Categoria Producto',
            'id_subcategoria_producto' => 'Id Subcategoria Producto',
            'nombre_producto' => 'Nombre Producto',
            'id_marca_producto' => 'Id Marca Producto',
            'descripcion' => 'Descripcion',
            'stock' => 'Stock',
            'path_imagen' => 'Path Imagen',
            'precio_compra' => 'Precio Compra',
            'precio_venta' => 'Precio Venta',
        ];
    }
}
