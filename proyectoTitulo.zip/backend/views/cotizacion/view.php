<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\Cotizacion */

$this->title = $model->id_cotizacion;
$this->params['breadcrumbs'][] = ['label' => 'Cotizaciones', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="cotizacion-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Actualizar', ['update', 'id' => $model->id_cotizacion], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Eliminar', ['delete', 'id' => $model->id_cotizacion], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => '¿Estás seguro que deseas eliminar este registro?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id_cotizacion',
            'fecha',
            'id_cliente',
            'comentario',
        ],
    ]) ?>
	
	<?php
	echo Html::a('<i class="fa glyphicon glyphicon-hand-up"></i> Generar documento PDF', ['/cotizacion/pdf', 'id_cotizacion'=> $model->id_cotizacion], [
		'class'=>'btn btn-danger', 
		'target'=>'_blank', 
		'data-toggle'=>'tooltip', 
		'title'=>'Cotizacion formal exportada a PDF'
	]);
?>
	

</div>
